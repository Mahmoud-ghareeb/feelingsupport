<?php

return array (
  'next' => 'التالي',
  'previous' => 'السابق',
);
