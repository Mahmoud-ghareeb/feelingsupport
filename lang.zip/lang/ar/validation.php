<?php

return array (
  'required' => 'ال :attribute حقل مطلوب',
);
